#include <iostream>
#include "sqlite3.h"

int main() {
    // SQLite 데이터베이스 연결
    sqlite3 *db;
    int rc = sqlite3_open("sj.db", &db);

    if (rc) {
        std::cerr << "Cannot open database: " << sqlite3_errmsg(db) << std::endl;
        return 1;
    }

    // 쿼리 실행
    sqlite3_stmt *stmt;
    const char *query = "SELECT name, kor, eng FROM students";
    rc = sqlite3_prepare_v2(db, query, -1, &stmt, NULL);

    if (rc != SQLITE_OK) {
        std::cerr << "Failed to fetch data: " << sqlite3_errmsg(db) << std::endl;
        return 1;
    }

    // 결과 출력
    while ((rc = sqlite3_step(stmt)) == SQLITE_ROW) {
        const unsigned char *name = sqlite3_column_text(stmt, 0);
        int kor = sqlite3_column_int(stmt, 1);
        int eng = sqlite3_column_int(stmt, 2);

        // 학생별 총점, 평균 계산 및 출력
        int total_score = kor + eng;
        float average_score = total_score / 2.0;

        std::cout << "Student: " << name << std::endl;
        std::cout << "Total Score: " << total_score << std::endl;
        std::cout << "Average Score: " << average_score << std::endl;
        std::cout << std::endl;
    }

    // 연결 종료
    sqlite3_finalize(stmt);
    sqlite3_close(db);

    return 0;
}
